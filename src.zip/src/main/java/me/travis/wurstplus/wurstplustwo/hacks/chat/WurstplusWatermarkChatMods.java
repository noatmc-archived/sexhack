package me.travis.wurstplus.wurstplustwo.hacks.chat;

import me.travis.wurstplus.Wurstplus;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;

public class WurstplusWatermarkChatMods extends WurstplusHack {
	public WurstplusWatermarkChatMods() {
		super(WurstplusCategory.WURSTPLUS_CHAT);

		this.name        = "Chat Watermark";
		this.tag         = "ChatWatermark";
		this.description = "auto skid kek";
	}
}
